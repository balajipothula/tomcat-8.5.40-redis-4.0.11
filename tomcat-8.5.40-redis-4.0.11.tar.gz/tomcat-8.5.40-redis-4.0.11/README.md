# tomcat-8.5.40
## alpine linux image with openjdk8-jre, tomcat-native, sqlite, redis.
### Author: BALAJI POTHULA <*balaji.pothula@techie.com*>

#### cloning tomcat-8.5.40 from github.
git clone https://github.com/balajipothula/tomcat-8.5.40.git

##### tomcat webapp setup.
sudo sh $HOME/tomcat-8.5.40/setup.sh
